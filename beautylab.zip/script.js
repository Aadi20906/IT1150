//alert("Welcome to my page! You`ll find some eastereggs over here!")
function bck(){
    document.body.style.background= 'url("wallpaperflare.com_wallpaper.jpg")';
    alert("You find one can you find something else?");
}
function dont(){
    x = 3
    alert("I told you...")
    while(x){
        alert("I told you... " + x)
        x=x-1;
    }  
    document.write("Bye")
    document.body.style.background='white';}

today = new Date();
BigDay = new Date("December 25, 2021");
msPerDay = 24 * 60 * 60 * 1000 ;
timeLeft = (BigDay.getTime() - today.getTime());
e_daysLeft = timeLeft / msPerDay;
daysLeft = Math.floor(e_daysLeft);
e_hrsLeft = (e_daysLeft - daysLeft)*24;
hrsLeft = Math.floor(e_hrsLeft);
minsLeft = Math.floor((e_hrsLeft - hrsLeft)*60);
document.write("<p class='mate'> There are only " + daysLeft + " days " + hrsLeft +" hours and " + minsLeft + " minutes left Until December 25th 2021 </p>");

function hide() {
    var x = document.getElementById("xmass");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
  }